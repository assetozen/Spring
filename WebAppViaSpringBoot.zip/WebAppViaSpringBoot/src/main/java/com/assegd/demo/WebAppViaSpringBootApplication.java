package com.assegd.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAppViaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAppViaSpringBootApplication.class, args);
	}
}
